package siw.spring.universita;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiwSpringUniversitaApplicationTests {

	@Test
	void contextLoads() {
	}

}
