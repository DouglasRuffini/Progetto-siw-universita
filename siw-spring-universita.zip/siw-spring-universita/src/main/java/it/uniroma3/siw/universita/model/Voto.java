package it.uniroma3.siw.universita.model;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**Classe 
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see 
 */

@Entity
public class Voto {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(nullable = true)
	private int voto;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private Studente studenti2esami;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private Esame esame2voto;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getVoto() {
		return voto;
	}

	public void setVoto(int voto) {
		this.voto = voto;
	}

	public Studente getStudenti2esami() {
		return studenti2esami;
	}

	public void setStudenti2esami(Studente studenti2esami) {
		this.studenti2esami = studenti2esami;
	}

	public Esame getEsame2voto() {
		return esame2voto;
	}

	public void setEsame2voto(Esame esame2voto) {
		this.esame2voto = esame2voto;
	}
	
	
}
