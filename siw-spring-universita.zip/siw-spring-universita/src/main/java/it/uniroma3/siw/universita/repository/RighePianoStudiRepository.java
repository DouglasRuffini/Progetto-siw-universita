package it.uniroma3.siw.universita.repository;
import org.springframework.data.repository.CrudRepository;
import it.uniroma3.siw.universita.model.RighePianoStudi;

/**Classe FacoltaService
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface RighePianoStudiRepository extends CrudRepository<RighePianoStudi, Long>{

}
