package it.uniroma3.siw.universita.controller.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import it.uniroma3.siw.universita.model.Docente;
import it.uniroma3.siw.universita.service.DocenteService;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class DocenteValidator implements Validator {


	@Autowired
	private DocenteService  docenteService;
	

private static final Logger logger = LoggerFactory.getLogger(DocenteValidator.class);
	
    
    @Override
	public boolean supports(Class<?> aClass) {
		return Docente.class.equals(aClass);
	}

	@Override
	public void validate(Object o, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nome", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cognome", "required");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "telefono", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "required");
		Docente  docente =(Docente)o;
		if (!errors.hasErrors()) {
			logger.debug("confermato: valori non nulli");
			if (this.docenteService.alreadyExists(Long.valueOf(docente.getId()))) {
				logger.debug("e' un duplicato");
				errors.reject("duplicato");
			}
		}
	}

	public boolean validation(Object o) {
		Docente  docente =(Docente)o;
	    
	    if((docente.getNome()==null)||(docente.getNome().isBlank()))
    		return false;    	    	
    	if((docente.getCognome()==null)||(docente.getCognome().isBlank()))
    		return false;
    	
    	if((docente.getTelefono()==null)||(docente.getTelefono().isBlank()))
    		return false;
    	if((docente.getEmail()==null)||(docente.getEmail().isBlank()))
    		return false;
		return true;
	}
	
	/**Valida l'eventualità che il tasto invio sia
	 * usato per modificare i dati gia presenti
	 * 
	 * @param o
	 * @return
	 */
	public boolean validaModifica(Object o) {
		Docente  docente =(Docente)o;
		if (this.docenteService.alreadyExists(Long.valueOf(docente.getId())))
			return true;
		return false;
	}
	
	public boolean validaFacolta(Object o) {
		Docente  docente =(Docente)o;
		if (this.docenteService.alreadyExists(Long.valueOf(docente.getId())))
			return true;
		return false;
	}
	
}
