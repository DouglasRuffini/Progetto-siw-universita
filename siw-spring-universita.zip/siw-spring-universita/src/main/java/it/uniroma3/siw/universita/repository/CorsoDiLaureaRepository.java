package it.uniroma3.siw.universita.repository;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.universita.model.CorsoDiLaurea;

/**Classe FacoltaService
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface CorsoDiLaureaRepository  extends CrudRepository<CorsoDiLaurea, Long> {
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT Distinct(corso_di_laurea.id) as id, corso_di_laurea.codicelaurea,  corso_di_laurea.titolo, corso_di_laurea.facolta2corsodilaurea_id "
    		+ "	FROM (corso  join corso_di_laurea  on corso.corsidilaurea_id = corso_di_laurea.id) join esame  on corso.id = esame.corsi2esami_id  "
    		+ " WHERE cast (esame.data as date) >= NOW() ORDER BY  corso_di_laurea.id; ", nativeQuery=true) 
	@Transactional
	public List<CorsoDiLaurea> findByCorsoCalendario();
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT corso_di_laurea.id, corso_di_laurea.codicelaurea,  corso_di_laurea.titolo, corso_di_laurea.facolta2corsodilaurea_id "
    		+ "	FROM (corso  join corso_di_laurea  on corso.corsidilaurea_id = corso_di_laurea.id) join esame  on corso.id = esame.corsi2esami_id  "
    		+ " WHERE cast (esame.data as date) >= NOW() ORDER BY  corso_di_laurea.id; ", nativeQuery=true) 
	@Transactional
	public List<CorsoDiLaurea> paginaInizialeCorsoCalendario();
	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT corso_di_laurea.id, corso_di_laurea.codicelaurea,  corso_di_laurea.titolo, corso_di_laurea.facolta2corsodilaurea_id "
    		+ "	FROM corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id "
    		+ " WHERE corso.codicecorso = :CodiceCorso ;", nativeQuery=true) 
	@Transactional
	public List<CorsoDiLaurea> findByCorsiCodiceCorso(@Param("CodiceCorso") String CodiceCorso);
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT (corso_di_laurea.id) as id, corso_di_laurea.codicelaurea,  corso_di_laurea.titolo, corso_di_laurea.facolta2corsodilaurea_id "
    		+ "	FROM corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id "
    		+ "   ORDER BY corso_di_laurea.id;", nativeQuery=true) 
	@Transactional
	public List<CorsoDiLaurea> corsoDiLaureaCorsi();
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT corso_di_laurea.id, corso_di_laurea.codicelaurea,  corso_di_laurea.titolo, corso_di_laurea.facolta2corsodilaurea_id "
    		+ "	FROM corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id "
    		+ "   ORDER BY corso_di_laurea.id;", nativeQuery=true) 
	@Transactional
	public List<CorsoDiLaurea> corsoDiLaureaCorsiPaginaIniziale();
	

	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT corso_di_laurea.id, corso_di_laurea.codicelaurea,  corso_di_laurea.titolo, corso_di_laurea.facolta2corsodilaurea_id "
    		+ "	FROM corso_di_laurea  "
    		+ " WHERE id = :idCorso ;", nativeQuery=true) 
	@Transactional
	public List<CorsoDiLaurea> findByIdCorsoLaurea(@Param("idCorso") Long idCorso);
	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT Distinct(corso_di_laurea.id) as id, corso_di_laurea.codicelaurea,  corso_di_laurea.titolo, corso_di_laurea.facolta2corsodilaurea_id  " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE studente.id = :idStudente and voto.voto >= 18  ",  nativeQuery=true)
	@Transactional
	public List<CorsoDiLaurea> listaEsamiSuperati(@Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT Distinct(corso_di_laurea.id) as id, corso_di_laurea.codicelaurea,  corso_di_laurea.titolo, corso_di_laurea.facolta2corsodilaurea_id  " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE  studente.id  = :idStudente and voto.voto between 1 and 17  ",  nativeQuery=true)
	@Transactional
	public List<CorsoDiLaurea> listaEsamiNonSuperati(@Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT Distinct(corso_di_laurea.id) as id, corso_di_laurea.codicelaurea,  corso_di_laurea.titolo, corso_di_laurea.facolta2corsodilaurea_id  " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE studente.id = :idStudente and voto.voto = 0  ",  nativeQuery=true)
	@Transactional
	public List<CorsoDiLaurea> listaEsamiPrenotati(@Param("idStudente") Long idStudente);
	
	
	
	
}
