package it.uniroma3.siw.universita.model;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**Classe 
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see 
 */

@Entity
public class Facolta {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(nullable = true)
	private String nome;
	private String telefono;
	private String email;
	private String indirizzo;
	
	@OneToMany(mappedBy = "facolta2studente", cascade = {CascadeType.ALL})
	private List<Studente> studente2facolta;
	
	@OneToMany(mappedBy = "facolta2docenti", cascade = {CascadeType.ALL})
	private List<Docente> docenti2facolta;
	
	@OneToMany(mappedBy = "facolta2corsodilaurea", cascade = {CascadeType.ALL})
	private List<CorsoDiLaurea> corsodilaurea2facolta;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public List<Studente> getStudente2facolta() {
		return studente2facolta;
	}

	public void setStudente2facolta(List<Studente> studente2facolta) {
		this.studente2facolta = studente2facolta;
	}

	public List<Docente> getDocenti2facolta() {
		return docenti2facolta;
	}

	public void setDocenti2facolta(List<Docente> docenti2facolta) {
		this.docenti2facolta = docenti2facolta;
	}

	public List<CorsoDiLaurea> getCorsodilaurea2facolta() {
		return corsodilaurea2facolta;
	}

	public void setCorsodilaurea2facolta(List<CorsoDiLaurea> corsodilaurea2facolta) {
		this.corsodilaurea2facolta = corsodilaurea2facolta;
	}
	
	

}
