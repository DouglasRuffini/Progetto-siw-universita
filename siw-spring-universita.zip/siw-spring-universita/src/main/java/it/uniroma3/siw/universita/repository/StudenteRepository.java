package it.uniroma3.siw.universita.repository;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.universita.model.Studente;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface StudenteRepository extends CrudRepository<Studente, Long> {
	
	@Modifying(clearAutomatically = true)
	@Query(value="update Studente set credentials2studenti_id = :credentials2studenti_id  where id = :idStudente", nativeQuery=true)
	@Transactional
	public void updateCredenzialiStudente(@Param("idStudente") Long id, @Param("credentials2studenti_id") Long credentials2studenti_id);
	
	@Modifying(clearAutomatically = true)
	@Query(value="select Studente.id, nome, cognome, email, matricola, studenti_id, credentials2studenti_id, facolta2studente_id from Studente join Credentials on Studente.credentials2studenti_id = Credentials.id where Studente.id = :id ", nativeQuery = true)
	@Transactional
	public List<Studente> ritornaCredenzialiStudente(@Param("id") Long id);
	
	@Modifying(clearAutomatically = true)
	@Query(value="update Studente set studenti_id = :corsoDiLaurea_id  where id = :idStudente", nativeQuery=true)
	@Transactional
	public void updateCorsoDiLaureaStudente(@Param("idStudente") Long id, @Param("corsoDiLaurea_id") Long corsoDiLaurea_id);
	
	
	@Modifying(clearAutomatically = true)
	@Query(value="select id, nome, cognome, email, matricola, studenti_id, credentials2studenti_id, facolta2studente_id from Studente  where credentials2studenti_id = :id ", nativeQuery = true)
	@Transactional
	public List<Studente> ritornaIndiceStudente(@Param("id") Long id);
	
	
	@Modifying(clearAutomatically = true)
	@Query(value="select id, nome, cognome, email, matricola, studenti_id, credentials2studenti_id, facolta2studente_id from Studente where id = :id and studenti_id is null ", nativeQuery = true)
	@Transactional
	public List<Studente> verificaIndiceCorsoDiLaureaStudenteNullo(@Param("id") Long id);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT  studente.id, studente.nome, cognome, studente.email, matricola, studenti_id, credentials2studenti_id, facolta2studente_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE corso.codicecorso = :codicecorso and esame.data = :data and corso.docenti_id = :iDdocenti  ORDER BY corso.codicecorso  ",  nativeQuery=true)
	@Transactional
	public List<Studente> listaEsamiPrenotatiPerDocenti(@Param("codicecorso") String codicecorso , @Param("data") String data, @Param("iDdocenti") Long iDdocenti  );
	
	
}
