package it.uniroma3.siw.universita.model;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**Classe Corso
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see Corso
 */

@Entity
public class Corso {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(nullable = true)
	private String codicecorso;
	private String nome;
	private int cfu;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private CorsoDiLaurea corsidilaurea;
	
	@OneToMany(mappedBy = "pianocorsi2righe", cascade = {CascadeType.ALL})
	private List<RighePianoStudi> righe2piani;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private Docente docenti;
	
	@OneToMany(mappedBy  = "corsi2esami", cascade = {CascadeType.ALL})
	private List<Esame> esami2corsi;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCodicecorso() {
		return codicecorso;
	}

	public void setCodicecorso(String codicecorso) {
		this.codicecorso = codicecorso;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCfu() {
		return cfu;
	}

	public void setCfu(int cfu) {
		this.cfu = cfu;
	}

	public CorsoDiLaurea getCorsidilaurea() {
		return corsidilaurea;
	}

	public void setCorsidilaurea(CorsoDiLaurea corsidilaurea) {
		this.corsidilaurea = corsidilaurea;
	}

	public List<RighePianoStudi> getRighe2piani() {
		return righe2piani;
	}

	public void setRighe2piani(List<RighePianoStudi> righe2piani) {
		this.righe2piani = righe2piani;
	}

	public Docente getDocenti() {
		return docenti;
	}

	public void setDocenti(Docente docenti) {
		this.docenti = docenti;
	}

	public List<Esame> getEsami2corsi() {
		return esami2corsi;
	}

	public void setEsami2corsi(List<Esame> esami2corsi) {
		this.esami2corsi = esami2corsi;
	}

	
	
	
	
}
