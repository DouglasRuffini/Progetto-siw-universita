package it.uniroma3.siw.universita.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import it.uniroma3.siw.universita.controller.validator.CorsoDiLaureaValidator;
import it.uniroma3.siw.universita.controller.validator.CorsoValidator;
import it.uniroma3.siw.universita.controller.validator.CredentialsValidator;
import it.uniroma3.siw.universita.controller.validator.DocenteValidator;
import it.uniroma3.siw.universita.controller.validator.EsameValidator;
import it.uniroma3.siw.universita.controller.validator.FacoltaValidator;
import it.uniroma3.siw.universita.controller.validator.PianoDiStudioValidator;
import it.uniroma3.siw.universita.controller.validator.RighePianoStudiValidator;
import it.uniroma3.siw.universita.controller.validator.StudenteValidator;
import it.uniroma3.siw.universita.controller.validator.VotoValidator;
import it.uniroma3.siw.universita.model.Corso;
import it.uniroma3.siw.universita.model.CorsoDiLaurea;
import it.uniroma3.siw.universita.model.Credentials;
import it.uniroma3.siw.universita.model.Docente;
import it.uniroma3.siw.universita.model.Esame;
import it.uniroma3.siw.universita.model.Facolta;
import it.uniroma3.siw.universita.model.PianoDiStudio;
import it.uniroma3.siw.universita.model.RighePianoStudi;
import it.uniroma3.siw.universita.model.Studente;
import it.uniroma3.siw.universita.model.Voto;
import it.uniroma3.siw.universita.service.CorsoDiLaureaService;
import it.uniroma3.siw.universita.service.CorsoService;
import it.uniroma3.siw.universita.service.CredentialsService;
import it.uniroma3.siw.universita.service.DocenteService;
import it.uniroma3.siw.universita.service.EsameService;
import it.uniroma3.siw.universita.service.FacoltaService;
import it.uniroma3.siw.universita.service.PianoDiStudioService;
import it.uniroma3.siw.universita.service.RighePianoStudiService;
import it.uniroma3.siw.universita.service.StudenteService;
import it.uniroma3.siw.universita.service.VotoService;

/**Classe  AuthenticationController
* 
* @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
*
*/

@Controller
public class AuthenticationController {
	@Autowired
	private CredentialsService credentialsService;
	
	@Autowired
	private CredentialsValidator credentialsValidator; 
	
	@Autowired
	private StudenteValidator studenteValidator;
	
	@Autowired
	private StudenteService studenteService;
	
	@Autowired
	private FacoltaService facoltaService;
	
	@Autowired
	private FacoltaValidator facoltaValidator; 
	
	@Autowired
	private DocenteService docenteService;
	
	@Autowired
	private DocenteValidator docenteValidator; 
	
	@Autowired
	private CorsoService corsoService;
	
	@Autowired
	private CorsoValidator corsoValidator;
	
	@Autowired
	private CorsoDiLaureaService corsoDiLaureaService;
	
	@Autowired
	private CorsoDiLaureaValidator corsoDiLaureaValidator;
	
	@Autowired
	private PianoDiStudioService pianoDiStudioService;
	
	@Autowired
	private PianoDiStudioValidator pianoDiStudioValidator;
	
	@Autowired
	private RighePianoStudiService righePianoStudiService;
	
	@Autowired
	private RighePianoStudiValidator righePianoStudiValidator;
	
	@Autowired
	private EsameService esameService;
	
	@Autowired
	private EsameValidator esameValidator;
	
	@Autowired
	private VotoService votoService;
	
	@Autowired
	private VotoValidator votoValidator;

	/*Metodi get autenticazione
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/registerUser", method = RequestMethod.GET) 
	public String showRegisterForm (Model model) {
		model.addAttribute("studente", new Studente());
		model.addAttribute("credentials", new Credentials());
		return "registerUser";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET) 
	public String showLoginForm (Model model) {
		return "login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET) 
	public String logout(Model model) {
		return "index"; 
	}

	@RequestMapping(value = "/default", method = RequestMethod.GET)
	public String defaultAfterLogin(Model model) {

		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE)) {
			return "supervisor/home";
		}
		if (credentials.getRuolo().equals(Credentials.ADMIN_ROLE)) {
			return "admin/home";
		}
		if (credentials.getRuolo().equals(Credentials.DEFAULT_ROLE)) {
			return "user/home";
		}
		return "home";
	}

	@RequestMapping(value = { "/registerUser" }, method = RequestMethod.POST)
	public String registerUser(@ModelAttribute("studente") Studente user,
			BindingResult userBindingResult,
			@ModelAttribute("credentials") Credentials credentials,
			BindingResult credentialsBindingResult,
			Model model) {

		/* validate user and credentials fields*/
		//        this.userValidator.validate(user, userBindingResult);
		//        this.credentialsValidator.validate(credentials, credentialsBindingResult);

		/* if neither of them had invalid contents, store the User and the Credentials into the DB*/
		//        if(!userBindingResult.hasErrors() && ! credentialsBindingResult.hasErrors()) {
		//            // set the user and store the credentials;
		//            // this also stores the User, thanks to Cascade.ALL policy
		
		
		if(this.studenteValidator.validateCognome(user) && this.studenteValidator.validateNome(user) && 
											this.credentialsValidator.validateMessagePassword(credentials) && 
													this.credentialsValidator.validateMessageUsername(credentials)) {
			
			credentialsService.saveCredentials(credentials);
			user.setCredentials2studenti(credentials);
			user.setMatricola(String.valueOf(credentials.getId()));
			if(!facoltaService.alreadyNotExists()) {
				for(Facolta f : facoltaService.tutteLeFacolta()) {
					user.setEmail(user.getNome().trim().replaceAll("\\s","") + "." + user.getCognome().trim().replaceAll("\\s","") +"@"+ f.getNome().trim().replaceAll("\\s","") + ".com");
					user.setFacolta2studente(f);
				}
			}		
			
			studenteService.saveUser(user);			
			return "registrationSuccessful";
		}	

		return "registerUser";
	}  
	
	
	/*Metodi get aggiungi
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/supervisor/aggiungi_info_universita", method = RequestMethod.GET) 
	public String aggiungiUniversita(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE)) {
			model.addAttribute("aggiungi_info_universita", new Facolta());
			return "supervisor/aggiungi_info_universita";
		}
		return "home";
	}
		
	@RequestMapping(value = "/supervisor/aggiungi_docente", method = RequestMethod.GET) 
	public String aggiungiDocente(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE)) {
			model.addAttribute("aggiungi_docente", new Docente());
			return "supervisor/aggiungi_docente";
		}
		return "home";
	}
	
	
	
	/* Metodi post aggiungi
	 * 
	 * @param aggiungi 
	 * @param model
	 * @param bindingResult
	 * @return
	 */
	@RequestMapping(value = "/supervisor/aggiungi_info_universita", method = RequestMethod.POST)
	public String addUniversita(@ModelAttribute("aggiungi_info_universita") Facolta aggiungi_info_universita, 
			Model model, BindingResult bindingResult) {
		if(!this.facoltaValidator.validation(aggiungi_info_universita))
			return "supervisor/aggiungi_info_universita";    	    	

		if(this.facoltaValidator.validaModifica(aggiungi_info_universita)) {
			this.facoltaService.aggiorna(aggiungi_info_universita); 
			model.addAttribute("visualizza_info_universita", this.facoltaService.tutteLeFacolta()); 
			return "supervisor/visualizza_info_universita";
		}

		this.facoltaValidator.validate(aggiungi_info_universita, bindingResult);
		if (!bindingResult.hasErrors()) {
			if(this.facoltaService.alreadyNotExists()) {
				this.facoltaService.inserisci(aggiungi_info_universita);  
				
				for(Docente c : this.docenteService.tuttiIDocenti()) {
					c.setFacolta2docenti(aggiungi_info_universita);
					this.docenteService.inserisci(c);
				}
				for(Studente s : this.studenteService.tuttiGliUtenti()) {
					s.setFacolta2studente(aggiungi_info_universita);
					this.studenteService.saveUser(s);
				}
				for(CorsoDiLaurea l : this.corsoDiLaureaService.tuttiICorsiDiLaurea()) {
					l.setFacolta2corsodilaurea(aggiungi_info_universita);
					this.corsoDiLaureaService.inserisci(l);
				}
				
			}
			model.addAttribute("visualizza_info_universita", this.facoltaService.tutteLeFacolta()); 
			return "supervisor/visualizza_info_universita";
		}
		return "supervisor/aggiungi_info_universita";
	}
	
	@RequestMapping(value = "/supervisor/aggiungi_docente", method = RequestMethod.POST)
	public String addDocente(@ModelAttribute("aggiungi_curatore") Docente aggiungi_docente,
			Model model, BindingResult bindingResult) {

		if(!this.docenteValidator.validation(aggiungi_docente))
			return "supervisor/aggiungi_docente"; 

		if(facoltaService.alreadyNotExists())
			return "supervisor/aggiungi_docente"; 
		
		
		if(this.docenteValidator.validaModifica(aggiungi_docente)) {
			this.docenteService.aggiorna(aggiungi_docente); 
			model.addAttribute("visualizza_docenti", this.docenteService.tuttiIDocenti());
			return "supervisor/visualizza_docenti";
		}
		
		this.docenteValidator.validate(aggiungi_docente, bindingResult);
		if (!bindingResult.hasErrors()) {
			Credentials c  = new Credentials();			
			this.docenteService.inserisci(aggiungi_docente);
			c.setPassword("password");
			c.setUsername(aggiungi_docente.getCognome() + String.valueOf(aggiungi_docente.getId()));			
			
			this.credentialsService.saveCredentialsDocente(c);
			this.docenteService.updateCredenzialiDocente(aggiungi_docente.getId(), c.getId());
			
			for(Facolta f : facoltaService.tutteLeFacolta())
				this.docenteService.associaFacolta(aggiungi_docente.getId(), f.getId());
			
			model.addAttribute("visualizza_docenti", this.docenteService.tuttiIDocenti());
			return "supervisor/visualizza_docenti";
		}
		return "supervisor/aggiungi_docente";
	}
	
	
	
	/*Metodi post modifica  
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/modifica_universita/{id}", method = RequestMethod.POST)
	public String modificaUniversita(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE))  {	
			if(this.facoltaService.alreadyExists(id)) {
				model.addAttribute("aggiungi_info_universita", this.facoltaService.facoltaPerId(id));        				    		
			}
			return "supervisor/aggiungi_info_universita";
		}
		return "home";
	}

	@RequestMapping(value = "/modifica_docente/{id}", method = RequestMethod.POST)
	public String modificaDocente(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE))  {	
			if(this.docenteService.alreadyExists(id)) {
				model.addAttribute("aggiungi_docente", this.docenteService.docentePerId(id));        				    		
			}
			return "supervisor/aggiungi_docente";
		}
		return "home";
	}
	
	/**/
	@RequestMapping(value = "/supervisor/modifica_credenziali", method = RequestMethod.POST)
	public String modificaCredenziali( @ModelAttribute("modifica_credenziali") Credentials modifica_credenziali, 
			Model model, 
			@RequestParam(name = "sub", required = false) Long id_docente,
			@RequestParam(name = "username", required = false) String username, 
			@RequestParam(name = "password", required = false) String password, 
			@RequestParam(name = "ruolo", required = false) String ruolo, 
			@RequestParam(name = "ruolo_cambiato", required = false) String ruolo_cambiato) {

		if(!this.credentialsValidator.validateMessageRuoloModifica(ruolo_cambiato) 
				&& !this.credentialsValidator.validateMessagePasswordModifica(password) 
				&& !this.credentialsValidator.validateMessageUsernameModifica(username) ) {
			this.credentialsService.aggiornaRuoloUtente(id_docente, ruolo_cambiato); 
			model.addAttribute("visualizza_utenti", this.docenteService.tuttiIDocenti());
			return "supervisor/visualizza_utenti";
		}    	

		return "supervisor/modifica_credenziali";
	}

	@RequestMapping(value = "/prenota_esame/{id}", method = RequestMethod.POST)
	public String aggiungiEsame(@PathVariable("id") Long id, Model model, @RequestParam(name = "sub", required = false) String data ) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (  (credentials.getRuolo().equals(Credentials.DEFAULT_ROLE)) )  {
			
			for(Studente s : this.studenteService.ritornaIndiceStudente(credentials.getId())) {
				
				String codice=null;
				for(Corso c : this.corsoService.corsoPerIndiceCorsi(id)) {						
					codice=c.getCodicecorso();	
				}

				if(this.esameService.findByEsamiSuperati(codice, s.getId()).isEmpty()) {
					/*Esame presente ma non superato*/
					if(this.esameService.findByEsamiPrenotatiNonEffettuati(codice, s.getId()).isEmpty()) {
						 
						Voto v = new Voto();
						for(Esame e : this.esameService.esamiPerIndex(id)) {
							v.setEsame2voto(e);
						}
						v.setStudenti2esami(s);
						this.votoService.inserisci(v);
						return "user/esameprenotato";
					}	
					else {
						
						if(this.esameService.findByEsamiNonSuperati(codice, s.getId()).size()>0) {
							Voto v = new Voto();
							for(Esame e : this.esameService.esamiPerIndex(id)) {
								v.setEsame2voto(e);
							}
							v.setStudenti2esami(s);
							this.votoService.inserisci(v);
							return "user/esameprenotato";
						} else {
							/*Esame superato*/
							model.addAttribute("corsolaurea", this.corsoDiLaureaService.esamiPerId(s.getStudenti().getId()));
							model.addAttribute("corsi", this.corsoService.corsoPerIndiceDiLaureaCorsi(s.getStudenti().getId()));
							model.addAttribute("esami", this.esameService.findByIDCorsoSuperato(s.getStudenti().getId()));
							return "user/visualizza_piano_studio"; 
						}	
					}
				}else {
					
					/*Esame superato*/
					model.addAttribute("corsolaurea", this.corsoDiLaureaService.esamiPerId(s.getStudenti().getId()));
					model.addAttribute("corsi", this.corsoService.corsoPerIndiceDiLaureaCorsi(s.getStudenti().getId()));
					model.addAttribute("esami", this.esameService.findByIDCorsoSuperato(s.getStudenti().getId()));
					return "user/visualizza_piano_studio"; 
				}							
			}									    		           
		}
		return "home";
	}
	
	@RequestMapping(value = "admin/verbalizza_esami", method = RequestMethod.POST) 
	public String verbalizzaEsami(Model model, @RequestParam("mydatetime") String data,   @RequestParam(name = "sub", required = false) String codicecorso ) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRuolo().equals(Credentials.ADMIN_ROLE))    {
			
			String dataEsami = null;
			

			dataEsami= formatoDataVecchioStile(data);
			
			Long IdDocente=null;
			
			for(Docente d : this.docenteService.docentePerCredenziali(credentials.getId())) {	
				IdDocente= d.getId();
				
			}
			
			if(this.esameService.listaEsamiPrenotatiPerDocenti(codicecorso, dataEsami, IdDocente).isEmpty()) {
				return "admin/esami_non_trovati";
			}				
			else {
				model.addAttribute("studenti", this.studenteService.listaEsamiPrenotatiPerDocenti(codicecorso, dataEsami, IdDocente));
				model.addAttribute("corsi", this.corsoService.listaEsamiPrenotatiPerDocenti(codicecorso, dataEsami, IdDocente));
				model.addAttribute("esami", this.esameService.listaEsamiPrenotatiPerDocenti(codicecorso, dataEsami, IdDocente));
				model.addAttribute("voti", this.votoService.listaEsamiPrenotatiPerDocenti(codicecorso, dataEsami, IdDocente));
				model.addAttribute("codicecorso", codicecorso);
				model.addAttribute("dataesame", dataEsami);
				return "admin/verbalizza_esami";
			}
			
		}
		return "home";
	}
	
	
	@RequestMapping(value = "admin/verbalizza_esame", method = RequestMethod.POST) 
	public String verbalizzaEsame(Model model, @RequestParam(name = "indice", required = false) Long indice, @RequestParam(name = "voto", required = false) int voto,
			 @RequestParam(name = "codicecorso", required = false) String codicecorso,  @RequestParam(name = "dataesame", required = false) String dataesame)  {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRuolo().equals(Credentials.ADMIN_ROLE))    {
			
			for(Voto v : this.votoService.aggiornaVotodocente(indice)) {
				v.setVoto(voto);
				this.votoService.inserisci(v);
			}
			
			Long IdDocente=null;
			for(Docente d : this.docenteService.docentePerCredenziali(credentials.getId())) {	
				IdDocente= d.getId();				
			}
			
			if(this.esameService.listaEsamiPrenotatiPerDocenti(codicecorso, dataesame, IdDocente).isEmpty()) {
				return "home";
			}				
			else {
				model.addAttribute("studenti", this.studenteService.listaEsamiPrenotatiPerDocenti(codicecorso, dataesame, IdDocente));
				model.addAttribute("corsi", this.corsoService.listaEsamiPrenotatiPerDocenti(codicecorso, dataesame, IdDocente));
				model.addAttribute("esami", this.esameService.listaEsamiPrenotatiPerDocenti(codicecorso, dataesame, IdDocente));
				model.addAttribute("voti", this.votoService.listaEsamiPrenotatiPerDocenti(codicecorso, dataesame, IdDocente));
				model.addAttribute("codicecorso", codicecorso);
				model.addAttribute("dataesame", dataesame);
				return "admin/verbalizza_esami";
			}
			
			
		}
		return "home";
	}
	
	
	
	
	/*Metodi post elimina
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/elimina_universita/{id}", method = RequestMethod.POST)
	public String removeUniversita(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE))  {
			if(facoltaService.alreadyExists(id)) {
//				this.facoltaService.dissociaDocenti(id);
				
				for(Docente c : this.docenteService.tuttiIDocenti()) {
					c.setFacolta2docenti(null);
					this.docenteService.inserisci(c);
				}
				for(Studente s : this.studenteService.tuttiGliUtenti()) {
					s.setFacolta2studente(null);
					this.studenteService.saveUser(s);
				}
				for(CorsoDiLaurea l : this.corsoDiLaureaService.tuttiICorsiDiLaurea()) {
					l.setFacolta2corsodilaurea(null);
					this.corsoDiLaureaService.inserisci(l);
				}
				
				
				this.facoltaService.eliminaFacoltaId(id);
			}
			model.addAttribute("visualizza_info_universita", this.facoltaService.tutteLeFacolta());
			return "supervisor/visualizza_info_universita";
		}
		return "home";
	}
	
	@RequestMapping(value = "/elimina_docente/{id}", method = RequestMethod.POST)
	public String removeDocente(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE))  {
			if(docenteService.alreadyExists(id)) {
				this.docenteService.dissociaCorsi(id);
				this.docenteService.dissociaFacolta(id);
				this.docenteService.eliminaDocenteId(id);
			}	
			model.addAttribute("visualizza_docenti", this.docenteService.tuttiIDocenti());
			return "supervisor/visualizza_docenti";
		}
		return "home";
	}
	
	
	
	
	/*Metodi get visualizza tutti
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/visualizza_info_universita", method = RequestMethod.GET) 
	public String visualizzaInfoUniversita(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE))    {
			model.addAttribute("visualizza_info_universita", this.facoltaService.tutteLeFacolta());
			return "supervisor/visualizza_info_universita";
		}
		return "home";
	}
	
	@RequestMapping(value = "/visualizza_docenti", method = RequestMethod.GET) 
	public String visualizzaDocenti(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE))    {
			model.addAttribute("visualizza_docenti", this.docenteService.tuttiIDocenti());
			return "supervisor/visualizza_docenti";
		}
		return "home";
	}
	
	/**/
	@RequestMapping(value = "/visualizza_utenti", method = RequestMethod.GET) 
	public String visualizzaTuttiGliUtenti(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE))    {
			model.addAttribute("visualizza_utenti", this.docenteService.credentialsIDocenti());
			return "supervisor/visualizza_utenti";
		}
		return "home";
	}

	@RequestMapping(value = "/visualizza_corsi_laurea_studenti", method = RequestMethod.GET) 
	public String visualizzaCorsiLaure(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (  (credentials.getRuolo().equals(Credentials.DEFAULT_ROLE)) ) {
			for(Studente s : this.studenteService.ritornaIndiceStudente(credentials.getId())) {					
				
				if(this.studenteService.alreadyExistsCorsoDiLaureaStudenteNullo(s.getId())) {
					model.addAttribute("visualizza_corsi_laurea", this.corsoDiLaureaService.tuttiICorsiDiLaurea());
					return "user/visualizza_corsi_laurea";
				}
				else {
					model.addAttribute("corsolaurea", this.corsoDiLaureaService.esamiPerId(s.getStudenti().getId()));
			    	model.addAttribute("corsi", this.corsoService.corsoPerIndiceDiLaureaCorsi(s.getStudenti().getId()));
					return "user/visualizza_corsi"; 
				}
			}						
		}
		return "home";
	}
	
	@RequestMapping(value = "/visualizza_piano_studio", method = RequestMethod.GET) 
	public String visualizzaPianoStudi(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (  (credentials.getRuolo().equals(Credentials.DEFAULT_ROLE)) ) {
			for(Studente s : this.studenteService.ritornaIndiceStudente(credentials.getId())) {					
				
				if(this.studenteService.alreadyExistsCorsoDiLaureaStudenteNullo(s.getId())) {
					model.addAttribute("visualizza_corsi_laurea", this.corsoDiLaureaService.tuttiICorsiDiLaurea());
					return "user/visualizza_corsi_laurea";
				}
				else {	
					model.addAttribute("corsolaurea", this.corsoDiLaureaService.esamiPerId(s.getStudenti().getId()));					
			    	model.addAttribute("corsi", this.corsoService.corsoPerIndiceDiLaureaCorsi(s.getStudenti().getId()));
			    	model.addAttribute("esami", this.esameService.findByIDCorsoSuperato(s.getStudenti().getId()));
					return "user/visualizza_piano_studio"; 
				}
			}						
		}
		return "home";
	}
	
	@RequestMapping(value = "/esami_superati", method = RequestMethod.GET) 
	public String visualizzaEsamiSuperatiInCarriera(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (  (credentials.getRuolo().equals(Credentials.DEFAULT_ROLE)) ) {
			for(Studente s : this.studenteService.ritornaIndiceStudente(credentials.getId())) {					
				
				if(this.studenteService.alreadyExistsCorsoDiLaureaStudenteNullo(s.getId())) {
					model.addAttribute("visualizza_corsi_laurea", this.corsoDiLaureaService.tuttiICorsiDiLaurea());
					return "user/visualizza_corsi_laurea";
				}
				else {	
					model.addAttribute("corsolaurea", this.corsoDiLaureaService.listaEsamiSuperati(s.getId()));					
			    	model.addAttribute("corsi", this.corsoService.listaEsamiSuperati(s.getId()));
			    	model.addAttribute("esami", this.esameService.listaEsamiSuperati(s.getId()));
			    	model.addAttribute("voti", this.votoService.listaEsamiSuperati(s.getId()));
					return "user/esami_superati"; 
				}
			}						
		}
		return "home";
	}
	
	@RequestMapping(value = "/esami_non_superati", method = RequestMethod.GET) 
	public String visualizzaEsamiNonSuperatiInCarriera(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (  (credentials.getRuolo().equals(Credentials.DEFAULT_ROLE)) ) {
			for(Studente s : this.studenteService.ritornaIndiceStudente(credentials.getId())) {					
				
				if(this.studenteService.alreadyExistsCorsoDiLaureaStudenteNullo(s.getId())) {
					model.addAttribute("visualizza_corsi_laurea", this.corsoDiLaureaService.tuttiICorsiDiLaurea());
					return "user/visualizza_corsi_laurea";
				}
				else {	
					model.addAttribute("corsolaurea", this.corsoDiLaureaService.listaEsamiNonSuperati(s.getId()));					
			    	model.addAttribute("corsi", this.corsoService.listaEsamiNonSuperati(s.getId()));
			    	model.addAttribute("esami", this.esameService.listaEsamiNonSuperati(s.getId()));
			    	model.addAttribute("voti", this.votoService.listaEsamiNonSuperati(s.getId()));
					return "user/esami_non_superati"; 
				}
			}						
		}
		return "home";
	}
	
	@RequestMapping(value = "/esami_prenotati", method = RequestMethod.GET) 
	public String visualizzaEsamiPrenotati(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (  (credentials.getRuolo().equals(Credentials.DEFAULT_ROLE)) ) {
			for(Studente s : this.studenteService.ritornaIndiceStudente(credentials.getId())) {					
				
				if(this.studenteService.alreadyExistsCorsoDiLaureaStudenteNullo(s.getId())) {
					model.addAttribute("visualizza_corsi_laurea", this.corsoDiLaureaService.tuttiICorsiDiLaurea());
					return "user/visualizza_corsi_laurea";
				}
				else {	
					
					model.addAttribute("corsolaurea", this.corsoDiLaureaService.listaEsamiPrenotati(s.getId()));
					
			    	model.addAttribute("corsi", this.corsoService.listaEsamiPrenotati(s.getId()));
			    	
			    	model.addAttribute("esami", this.esameService.listaEsamiPrenotati(s.getId()));

					return "user/esami_prenotati"; 
				}
			}						
		}
		return "home";
	}
	
	@RequestMapping(value = "admin/corsi_tenuti", method = RequestMethod.GET) 
	public String visualizzaCorsiTenuti(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRuolo().equals(Credentials.ADMIN_ROLE))    {

			for(Docente d : this.docenteService.docentePerCredenziali(credentials.getId())) {	
				model.addAttribute("corsi", this.corsoService.listaCorsiPerDocenti(d.getId()));
			}
			return "admin/corsi_tenuti";
		}
		return "home";
	}
	
	
	
	
	
	/*Metodo get visualizza per indice
	 * 
	 * @param id
	 * @param model
	 * @return
	 */	
	@RequestMapping(value = "/visualizza_docente/{id}", method = RequestMethod.GET) 
	public String visualizzaDocente(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE))    {
			model.addAttribute("visualizza_docente", this.docenteService.docentePerId(id));
			model.addAttribute("corsi", this.corsoService.corsoDocente(id));
			return "supervisor/visualizza_docente";
		}
		return "home";
	}
	
	/**/
	@RequestMapping(value = "supervisor/visualizza_credenziali/{id}", method = RequestMethod.GET) 
	public String visualizzaCredenziali(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRuolo().equals(Credentials.SUPERVISOR_ROLE))    {
			model.addAttribute("associa_credenziali", id);


			if(this.credentialsService.ritornaCredenziali(id)!=null)
				credentials = this.credentialsService.getCredentials(this.credentialsService.ritornaCredenziali(id));
			model.addAttribute("visualizza_credenziali_username", credentials.getUsername());
			model.addAttribute("visualizza_credenziali_password", credentials.getPassword());
			model.addAttribute("visualizza_credenziali_ruolo", credentials.getRuolo());
			model.addAttribute("visualizza_credenziali_id", credentials.getId());
			return "supervisor/modifica_credenziali";

		}
		return "home";
	}
	
	@RequestMapping(value = "/visualizza_corsi/{id}", method = RequestMethod.GET)
	public String associaCorsoDiLaurea(@PathVariable("id") Long id, Model model ) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (  (credentials.getRuolo().equals(Credentials.DEFAULT_ROLE)) )  {
			
			for(Studente s : this.studenteService.ritornaIndiceStudente(credentials.getId())) {
				//this.studenteService.updateCorsoDiLaureaStudente(s.getId(), id);
				for(CorsoDiLaurea l : this.corsoDiLaureaService.findById(id)) {
					s.setStudenti(l);
					this.studenteService.saveUser(s);
					PianoDiStudio p = new PianoDiStudio();
					p.setProtocollo(String.valueOf(s.getId() + "-" + l.getCodicelaurea() +"-" + s.getMatricola()));
					this.pianoDiStudioService.inserisci(p);
					RighePianoStudi r; 
					
					for(Corso c : this.corsoService.corsoPerIndiceDiLaureaCorsi(id)) {
						r = new RighePianoStudi();
						r.setPiani2righe(p);
						r.setPiani2studenti(s);
						r.setPianocorsi2righe(c);
						this.righePianoStudiService.inserisci(r);
					}
				}
				
			}
				
			
			model.addAttribute("corsolaurea", this.corsoDiLaureaService.esamiPerId(id));
	    	model.addAttribute("corsi", this.corsoService.corsoPerIndiceDiLaureaCorsi(id));
	    	model.addAttribute("esami", this.esameService.findByIDCorsoSuperato(id));
	    	return "user/visualizza_piano_studio";     		           
		}
		return "home";
	}
		
	
	/**Utilità formato data
	 * 
	 * @param dataDaFormattare
	 * @return
	 */
	
	private String formatoDataVecchioStile(String dataDaFormattare) {
		if(dataDaFormattare!=null) {
			/*yyyy-mm-dd --> 0123-56-89*/ 
			String text =  dataDaFormattare.substring(8,10)+ "-" + dataDaFormattare.substring(5,7) + "-"+ dataDaFormattare.substring(0,4);
			return text;	    	
		}
		else {
			return dataDaFormattare;
		}
	}

	private String riformatoDataVecchioStile(String dataDaFormattare) {
		if(dataDaFormattare!=null) {
			/*dd-mm-yyyy --> 01-34-6789*/
			
			String text =  dataDaFormattare.substring(6,10)+ "-" + dataDaFormattare.substring(3,5) + "-"+ dataDaFormattare.substring(0,2);
			return text;	    	
		}
		else {
			return dataDaFormattare;
		}
	}
	
	
	
	

}
