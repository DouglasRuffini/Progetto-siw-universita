package it.uniroma3.siw.universita.controller.validator;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import it.uniroma3.siw.universita.model.Studente;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class StudenteValidator  implements Validator {
	final Integer MAX_NAME_LENGTH = 100;
    final Integer MIN_NAME_LENGTH = 2;

    @Override
    public void validate(Object o, Errors errors) {
        Studente studente = (Studente) o;
        String nome = studente.getNome().trim();
        String cognome = studente.getCognome().trim();
       
        if (nome.isEmpty())
            errors.rejectValue("nome", "required");
        else if (nome.length() < MIN_NAME_LENGTH || nome.length() > MAX_NAME_LENGTH)
            errors.rejectValue("nome", "size");

        if (cognome.isEmpty())
            errors.rejectValue("cognome", "required");
        else if (cognome.length() < MIN_NAME_LENGTH || cognome.length() > MAX_NAME_LENGTH)
            errors.rejectValue("cognome", "size");
        
    }

    public boolean validateNome(Object o) {
    	Studente studente = (Studente) o;
        String nome = studente.getNome().trim();         
       
        if (nome.isEmpty())
           return false;
        if (nome.length() < MIN_NAME_LENGTH || nome.length() > MAX_NAME_LENGTH)
           return false;
        return true;
        
    }
    
    public boolean validateCognome(Object o) {
    	Studente studente = (Studente) o;
        String cognome = studente.getCognome().trim();

        if (cognome.isEmpty())
            return false;
        if (cognome.length() < MIN_NAME_LENGTH || cognome.length() > MAX_NAME_LENGTH)
            return false;
        return true;
        
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return Studente.class.equals(clazz);
    }

}
