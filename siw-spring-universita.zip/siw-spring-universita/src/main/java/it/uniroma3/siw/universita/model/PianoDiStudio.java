package it.uniroma3.siw.universita.model;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**Classe 
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see 
 */

@Entity
public class PianoDiStudio {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(nullable = true)
	private String protocollo;
	
	
	@ManyToOne( cascade = {CascadeType.ALL})
    private Corso piani2corsi;
	
	@ManyToOne( cascade = {CascadeType.ALL})
    private Studente piani2studenti;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	
	public String getProtocollo() {
		return protocollo;
	}

	public void setProtocollo(String protocollo) {
		this.protocollo = protocollo;
	}

	public Corso getPiani2corsi() {
		return piani2corsi;
	}

	public void setPiani2corsi(Corso piani2corsi) {
		this.piani2corsi = piani2corsi;
	}

	public Studente getPiani2studenti() {
		return piani2studenti;
	}

	public void setPiani2studenti(Studente piani2studenti) {
		this.piani2studenti = piani2studenti;
	}
	
	
}
