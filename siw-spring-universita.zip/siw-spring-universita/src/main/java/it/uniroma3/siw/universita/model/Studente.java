package it.uniroma3.siw.universita.model;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**Classe 
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see 
 */

@Entity
public class Studente {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(nullable = true)
	private String nome;
	private String cognome;
	private String matricola;
	private String email;

		
	@OneToMany(mappedBy = "studenti2esami", cascade = {CascadeType.ALL})
	private List<Voto> esami2studenti;
	
	@OneToMany(mappedBy = "piani2studenti", cascade = {CascadeType.ALL})
	private List<RighePianoStudi> studenti2piani;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private Facolta facolta2studente;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private CorsoDiLaurea studenti;
	
	@OneToOne(cascade = {CascadeType.ALL})
	private Credentials credentials2studenti;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getMatricola() {
		return matricola;
	}

	public void setMatricola(String matricola) {
		this.matricola = matricola;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Credentials getCredentials2studenti() {
		return credentials2studenti;
	}

	public void setCredentials2studenti(Credentials credentials2studenti) {
		this.credentials2studenti = credentials2studenti;
	}

	public CorsoDiLaurea getStudenti() {
		return studenti;
	}

	public void setStudenti(CorsoDiLaurea studenti) {
		this.studenti = studenti;
	}

	public List<Voto> getEsami2studenti() {
		return esami2studenti;
	}

	public void setEsami2studenti(List<Voto> esami2studenti) {
		this.esami2studenti = esami2studenti;
	}

	public List<RighePianoStudi> getStudenti2piani() {
		return studenti2piani;
	}

	public void setStudenti2piani(List<RighePianoStudi> studenti2piani) {
		this.studenti2piani = studenti2piani;
	}

	public Facolta getFacolta2studente() {
		return facolta2studente;
	}

	public void setFacolta2studente(Facolta facolta2studente) {
		this.facolta2studente = facolta2studente;
	}

	

}
