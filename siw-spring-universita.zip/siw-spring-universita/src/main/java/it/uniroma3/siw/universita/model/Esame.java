package it.uniroma3.siw.universita.model;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**Classe 
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see 
 */

@Entity
public class Esame {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(nullable = true)
	private String data;
	
	@OneToMany(mappedBy = "esame2voto", cascade = {CascadeType.ALL})
	private List<Voto> voto2esame;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private Corso corsi2esami;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public List<Voto> getVoto2esame() {
		return voto2esame;
	}

	public void setVoto2esame(List<Voto> voto2esame) {
		this.voto2esame = voto2esame;
	}

	public Corso getCorsi2esami() {
		return corsi2esami;
	}

	public void setCorsi2esami(Corso corsi2esami) {
		this.corsi2esami = corsi2esami;
	}
	
    
	
}
