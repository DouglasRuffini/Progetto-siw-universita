package it.uniroma3.siw.universita.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.universita.model.Docente;
import it.uniroma3.siw.universita.repository.DocenteRepository;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class DocenteService {
	@Autowired
	private DocenteRepository docenteRepository; 
	
	
	@Transactional
	public Docente inserisci(Docente docente) {
		return (Docente) docenteRepository.save(docente);
	}
	
	@Transactional
	public void dissociaCorsi(Long id) {
		docenteRepository.dissociaCorso(id);
	}
	
	@Transactional
	public void dissociaFacolta(Long id) {
		docenteRepository.dissociaUniversita(id);
	}
	
	@Transactional
	public void associaFacolta(Long id, Long idFacolta) {
		docenteRepository.associaUniversita(id, idFacolta);
	}
	
	@Transactional
	public void dissociaCredentials(Long id) {
		docenteRepository.dissociaCredentials(id);
	}
	
	@Transactional
	public void aggiorna(Docente docente) {
		docenteRepository.update(docente.getId(), docente.getNome(), docente.getCognome(), docente.getTelefono(), docente.getEmail());
	}
	
	@Transactional
	public void eliminaDocente(Docente docente) {
		docenteRepository.delete(docente);
	}
	
	@Transactional
	public void eliminaDocenteId(Long id) {
		docenteRepository.deleteById(id);
	}
	
	
	@Transactional
	public List<Docente> docentePerNomeAndCognome(String nome, String cognome) {
		return docenteRepository.findByNomeAndCognome(nome, cognome);
	}

	@Transactional
	public List<Docente> tuttiIDocenti() {
		return (List<Docente>) docenteRepository.findAll();
	}
	
	@Transactional
	public List<Docente> credentialsIDocenti() {
		return (List<Docente>) docenteRepository.ritornaCredenzialiDocenti();
	}
	
	@Transactional
	public void updateCredenzialiDocente(Long id, Long credentials_id) {
		docenteRepository.updateCredenzialiDocente(id, credentials_id);
	}

	@Transactional
	public Docente docentePerId(Long id) {
		Optional<Docente> docente =docenteRepository.findById(id);

		if (docente.isPresent())
			return docente.get();
		else 
			return null;
	}

	@Transactional
	public boolean alreadyExistsDocenteNomeAndCognome(Docente docente) {
		List<Docente> doc = this.docenteRepository.findByNomeAndCognome(docente.getNome(), docente.getCognome());
		if (doc.size() > 0)
			return true;
		else 
			return false;
	}
	
	@Transactional
	public boolean alreadyExistsDocenteNomeOrCognome(Docente docente) {
		List<Docente> doc = this.docenteRepository.findByNomeOrCognome(docente.getNome(), docente.getCognome());
		if (doc.size() > 0)
			return true;
		else 
			return false;
	}

	@Transactional
	public boolean alreadyExists(Long id) {
		return this.docenteRepository.existsById(id);
	}
	
	@Transactional
	public List<Docente> docentePerIndex(Long id){
		return (List<Docente>) docenteRepository.docentePerIndex(id);
	}
	
	@Transactional
	public List<Docente> docentePerCredenziali(Long id){
		return (List<Docente>) docenteRepository.docentePerCredenziali(id);
	}
	
}


















