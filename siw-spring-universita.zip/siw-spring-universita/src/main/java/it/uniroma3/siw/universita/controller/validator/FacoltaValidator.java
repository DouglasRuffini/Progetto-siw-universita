package it.uniroma3.siw.universita.controller.validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import it.uniroma3.siw.universita.model.Facolta;
import it.uniroma3.siw.universita.service.FacoltaService;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class FacoltaValidator implements Validator {

	@Autowired
	private FacoltaService facoltaService;
	
	private static final Logger logger = LoggerFactory.getLogger(FacoltaValidator.class);
	
	@Override
	public boolean supports(Class<?> clazz) {		
		return Facolta.class.equals(clazz);
	}

	@Override
	public void validate(Object o, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nome", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "indirizzo", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "telefono", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "required");
		Facolta facolta = (Facolta)o;
		
		if (!errors.hasErrors()) {
			logger.debug("confermato: valori non nulli");
			if (this.facoltaService.alreadyExists(Long.valueOf(facolta.getId()))) {
				logger.debug("e' un duplicato");
				errors.reject("duplicato");
			}
		}
		
	}
	
	public boolean validation(Object o) {
		Facolta facolta = (Facolta)o;
		if((facolta.getNome()==null)||(facolta.getNome().isBlank()))
    		return false;    	    	
    	if((facolta.getIndirizzo()==null)||(facolta.getIndirizzo().isBlank()))
    		return false;
    	if((facolta.getTelefono()==null)||(facolta.getTelefono().isBlank()))
    		return false;
    	if((facolta.getEmail()==null)||(facolta.getEmail().isBlank()))
    		return false;
    	
		return true;
	}

	
	/**Valida l'eventualità che il tasto invio sia
	 * usato per modificare i dati gia presenti
	 * 
	 * @param o
	 * @return
	 */
	public boolean validaModifica(Object o) {
		Facolta facolta = (Facolta)o;
		if (this.facoltaService.alreadyExists(Long.valueOf(facolta.getId())))
			return true;
		return false;
	}

}
