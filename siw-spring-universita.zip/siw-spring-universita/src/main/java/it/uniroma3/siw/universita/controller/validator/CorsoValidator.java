package it.uniroma3.siw.universita.controller.validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import it.uniroma3.siw.universita.model.Corso;
import it.uniroma3.siw.universita.service.CorsoService;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class CorsoValidator implements Validator{
	@Autowired
	private CorsoService corsoService;
	
	private static final Logger logger = LoggerFactory.getLogger(CorsoValidator.class);
	
	@Override
	public boolean supports(Class<?> clazz) {		
		return Corso.class.equals(clazz);
	}

	@Override
	public void validate(Object o, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nome", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "codicecorso", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cfu", "required");

		Corso corso = (Corso)o;
		
		if (!errors.hasErrors()) {
			logger.debug("confermato: valori non nulli");
			if (this.corsoService.alreadyExists(Long.valueOf(corso.getId()))) {
				logger.debug("e' un duplicato");
				errors.reject("duplicato");
			}
		}
		
	}
	
	public boolean validation(Object o) {
		Corso corso = (Corso)o;
		if((corso.getNome()==null)||(corso.getNome().isBlank()))
    		return false;    	    	
    	if((corso.getCodicecorso()==null)||(corso.getCodicecorso().isBlank()))
    		return false;
    	if((String.valueOf(corso.getCfu())==null)||(String.valueOf(corso.getCfu()).isBlank()))
    		return false;
    	
		return true;
	}

	
	/**Valida l'eventualità che il tasto invio sia
	 * usato per modificare i dati gia presenti
	 * 
	 * @param o
	 * @return
	 */
	public boolean validaModifica(Object o) {
		Corso corso = (Corso)o;
		if (this.corsoService.alreadyExists(Long.valueOf(corso.getId())))
			return true;
		return false;
	}

}
