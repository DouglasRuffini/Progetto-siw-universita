package it.uniroma3.siw.universita.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.universita.model.Corso;
import it.uniroma3.siw.universita.model.CorsoDiLaurea;
import it.uniroma3.siw.universita.repository.CorsoDiLaureaRepository;
import it.uniroma3.siw.universita.repository.CorsoRepository;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class CorsoDiLaureaService {
	@Autowired
	private CorsoDiLaureaRepository corsoDiLaureaRepository;
	
	@Autowired
	private CorsoRepository corsoRepository;
	
	@Transactional
	public CorsoDiLaurea inserisci(CorsoDiLaurea esami) {
		return (CorsoDiLaurea) corsoDiLaureaRepository.save(esami);
	}
	
	@Transactional
	public List<CorsoDiLaurea> findByCorsiCodiceCorso( String CodiceCorso) {
		return (List<CorsoDiLaurea>) corsoDiLaureaRepository.findByCorsiCodiceCorso(CodiceCorso);
	}
	
	@Transactional
	public List<CorsoDiLaurea> findById(Long id) {			
		return (List<CorsoDiLaurea>) corsoDiLaureaRepository.findByIdCorsoLaurea(id);
	}
	
	@Transactional
	public void eliminaCorsoDiLaurea(CorsoDiLaurea corsodilaurea) {
		corsoDiLaureaRepository.delete(corsodilaurea);
	}
	
	@Transactional
	public void eliminaCorsoDiLaureaId(Long id) {
		corsoDiLaureaRepository.deleteById(id);
	}
	
	@Transactional
	public List<CorsoDiLaurea> tuttiICorsiDiLaurea() {
		return (List<CorsoDiLaurea>) corsoDiLaureaRepository.findAll();
	}

	@Transactional
	public CorsoDiLaurea esamiPerId(Long id) {
		Optional<CorsoDiLaurea> corsi =corsoDiLaureaRepository.findById(id);

		if (corsi.isPresent())
			return corsi.get();
		else 
			return null;
	}
	
	@Transactional
	public boolean alreadyExists(Long id) {
		return this.corsoDiLaureaRepository.existsById(id);
	}
	
	@Transactional
	public boolean alreadyNotExists() {
		if(this.tuttiICorsiDiLaurea().isEmpty())
			return true;
		return false;
	}
	
	/*query pagina Corso di laurea*/
	
	@Transactional
	public List<CorsoDiLaurea> corsoDiLaureaCorsi() {
		return (List<CorsoDiLaurea>) corsoDiLaureaRepository.corsoDiLaureaCorsi();
	}
	
	@Transactional
	public List<Corso> corsoDiLaureaCorso() {
		return (List<Corso>) corsoRepository.corsoDiLaureaCorsi();
	}
	
	@Transactional
	public List<CorsoDiLaurea> corsoDiLaureaCorsiPaginaIniziale(){
		return (List<CorsoDiLaurea>) corsoDiLaureaRepository.corsoDiLaureaCorsiPaginaIniziale();
	}
	
	@Transactional
	public List<CorsoDiLaurea> paginaInizialeCorsoCalendario(){
		return (List<CorsoDiLaurea>) corsoDiLaureaRepository.paginaInizialeCorsoCalendario();
	}

/*lista esami*/
	
	@Transactional
	public List<CorsoDiLaurea> listaEsamiSuperati(Long idStudente){
		return (List<CorsoDiLaurea>) corsoDiLaureaRepository.listaEsamiSuperati(idStudente);
	}
	
	@Transactional
	public List<CorsoDiLaurea> listaEsamiNonSuperati(Long idStudente){
		return (List<CorsoDiLaurea>) corsoDiLaureaRepository.listaEsamiNonSuperati(idStudente);
	}
	
	@Transactional
	public List<CorsoDiLaurea> listaEsamiPrenotati(Long idStudente){
		return (List<CorsoDiLaurea>) corsoDiLaureaRepository.listaEsamiPrenotati(idStudente);
	}

	
	
}
