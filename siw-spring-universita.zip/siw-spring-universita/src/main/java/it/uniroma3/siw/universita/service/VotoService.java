package it.uniroma3.siw.universita.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.universita.model.Voto;
import it.uniroma3.siw.universita.repository.VotoRepository;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class VotoService {
	
	
	@Autowired
	private VotoRepository votoRepository;
	
	
	
	@Transactional
	public Voto inserisci(Voto voto) {
		return (Voto) votoRepository.save(voto);
	}	
	
	@Transactional
	public void eliminaVoto(Voto voto) {
		votoRepository.delete(voto);
	}
	
	@Transactional
	public void eliminaVotoId(Long id) {
		votoRepository.deleteById(id);
	}	
	
	@Transactional
	public Voto votoPerId(Long id) {
		Optional<Voto> voto =votoRepository.findById(id);

		if (voto.isPresent())
			return voto.get();
		else 
			return null;
	}
	
	@Transactional
	public boolean alreadyExists(Long id) {
		return this.votoRepository.existsById(id);
	}
	
/*lista esami*/
	
	@Transactional
	public List<Voto> listaEsamiSuperati(Long idStudente){
		return (List<Voto>) votoRepository.listaEsamiSuperati(idStudente);
	}
	
	@Transactional
	public List<Voto> listaEsamiNonSuperati(Long idStudente){
		return (List<Voto>) votoRepository.listaEsamiNonSuperati(idStudente);
	}
	
	@Transactional
	public List<Voto> listaEsamiPrenotati(Long idStudente){
		return (List<Voto>) votoRepository.listaEsamiPrenotati(idStudente);
	}
	
	@Transactional
	public List<Voto> listaEsamiPrenotatiPerDocenti(String codicecorso ,String data, Long iDdocenti  ){
		return (List<Voto>) this.votoRepository.listaEsamiPrenotatiPerDocenti(codicecorso , data, iDdocenti);
	}
	
	@Transactional
	public List<Voto> aggiornaVotodocente(Long id ){
		return (List<Voto>) this.votoRepository.aggiornaVotodocente(id );
	}
	
	
	
	
	
	
	
	
}
