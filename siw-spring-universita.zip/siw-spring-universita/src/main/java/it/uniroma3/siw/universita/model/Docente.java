package it.uniroma3.siw.universita.model;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**Classe Docente
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see Docente
 */

@Entity
public class Docente {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(nullable = true)
	private String nome;
	private String cognome;
	private String telefono;
	private String email;
	
	@OneToMany(mappedBy = "docenti", cascade = {CascadeType.ALL})
	private List<Corso> corso2docente;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private Facolta facolta2docenti;
	
	@OneToOne(cascade = {CascadeType.ALL})
	private Credentials credentials2docenti;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Corso> getCorso2docente() {
		return corso2docente;
	}

	public void setCorso2docente(List<Corso> corso2docente) {
		this.corso2docente = corso2docente;
	}

	public Facolta getFacolta2docenti() {
		return facolta2docenti;
	}

	public void setFacolta2docenti(Facolta facolta2docenti) {
		this.facolta2docenti = facolta2docenti;
	}

	public Credentials getCredentials2docenti() {
		return credentials2docenti;
	}

	public void setCredentials2docenti(Credentials credentials2docenti) {
		this.credentials2docenti = credentials2docenti;
	}
	
	
	
	
	
}
