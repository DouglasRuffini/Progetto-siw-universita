package it.uniroma3.siw.universita.repository;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.universita.model.Corso;

/**Classe FacoltaService
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface CorsoRepository  extends CrudRepository<Corso, Long>{
	
	/*le join con risultato per entita devono essere chiamate nel repository dell'entità stessa*/
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT corso.id,  codicecorso, nome, cfu, corsidilaurea_id, docenti_id"
    		+ "	FROM (corso  join corso_di_laurea  on corso.corsidilaurea_id = corso_di_laurea.id) join esame  on corso.id = esame.corsi2esami_id "
    		+ " WHERE cast (esame.data as date) >= NOW()  ORDER BY corso_di_laurea.id", nativeQuery=true) 
	@Transactional
	public List<Corso> calendarioEsami();
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT corso.id,  codicecorso, nome, cfu, corsidilaurea_id, docenti_id"
    		+ "	FROM (corso  join corso_di_laurea  on corso.corsidilaurea_id = corso_di_laurea.id) join esame  on corso.id = esame.corsi2esami_id "
    		+ " ORDER BY  corso_di_laurea.id", nativeQuery=true) 
	@Transactional
	public List<Corso> corsoDiLaureaCorsi();
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT id,  codicecorso, nome, cfu, corsidilaurea_id, docenti_id"
    		+ "	FROM Corso "
    		+ " WHERE docenti_id = :idDocente ORDER BY  codicecorso", nativeQuery=true) 
	@Transactional
	public List<Corso> corsiDocente(@Param("idDocente") Long idDocente);

	public List<Corso> findByNome(String nome);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT id,  codicecorso, nome, cfu, corsidilaurea_id, docenti_id"
    		+ "	FROM corso "
    		+ " WHERE corso.corsidilaurea_id = :idCorsoDiLaurea ", nativeQuery=true) 
	@Transactional
	public List<Corso> corsoPerIndiceDiLaureaCorsi(@Param("idCorsoDiLaurea") Long idCorsoDiLaurea);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT id,  codicecorso, nome, cfu, corsidilaurea_id, docenti_id"
    		+ "	FROM corso "
    		+ " WHERE id = :id ", nativeQuery=true) 
	@Transactional
	public List<Corso> corsoPerIndiceCorsi(@Param("id") Long id);
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT corso.id,  codicecorso, corso.nome, cfu, corsidilaurea_id, docenti_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE studente.id = :idStudente and voto.voto >= 18 ORDER BY corso.codicecorso ",  nativeQuery=true)
	@Transactional
	public List<Corso> listaEsamiSuperati(@Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT  corso.id,  codicecorso, corso.nome, cfu, corsidilaurea_id, docenti_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE  studente.id  = :idStudente and voto.voto between 1 and 17  ORDER BY corso.codicecorso  ",  nativeQuery=true)
	@Transactional
	public List<Corso> listaEsamiNonSuperati(@Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT  corso.id,  codicecorso, corso.nome, cfu, corsidilaurea_id, docenti_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE studente.id = :idStudente and voto.voto = 0  ORDER BY corso.codicecorso  ",  nativeQuery=true)
	@Transactional
	public List<Corso> listaEsamiPrenotati(@Param("idStudente") Long idStudente);
	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT  corso.id,  codicecorso, corso.nome, cfu, corsidilaurea_id, docenti_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ "  WHERE corso.codicecorso = :codicecorso and esame.data = :data and corso.docenti_id = :iDdocenti  ORDER BY corso.codicecorso   ",  nativeQuery=true)
	@Transactional
	public List<Corso> listaEsamiPrenotatiPerDocenti(@Param("codicecorso") String codicecorso , @Param("data") String data, @Param("iDdocenti") Long iDdocenti  );
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT corso.id,  codicecorso, corso.nome, cfu, corsidilaurea_id, docenti_id " 
    		+ " FROM corso "
    		+ "  WHERE corso.docenti_id = :iDdocenti  ORDER BY corso.codicecorso   ",  nativeQuery=true)
	@Transactional
	public List<Corso> listaCorsiPerDocenti(@Param("iDdocenti") Long iDdocenti  );
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
