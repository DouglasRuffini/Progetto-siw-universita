package it.uniroma3.siw.universita.repository;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.universita.model.Credentials;

/**Classe CredentialsRepository
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface CredentialsRepository  extends CrudRepository<Credentials, Long>{

	Optional<Credentials> findByUsername(String username);
	
	@Modifying(clearAutomatically = true)
    @Query(value="update Credentials set  ruolo = :ruolo where  id = :idUtente", nativeQuery=true)
	@Transactional
	public void updateRuolo(@Param("idUtente") Long id, @Param("ruolo") String ruolo);
	
	@Modifying(clearAutomatically = true)
	@Query(value="select id, username, password, ruolo from Credentials where id = :id ", nativeQuery = true)
	@Transactional
	public List<Credentials> ritornaCredenziali(@Param("id") Long id);
	
}
