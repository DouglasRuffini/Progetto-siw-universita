package it.uniroma3.siw.universita.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.universita.model.Credentials;
import it.uniroma3.siw.universita.repository.CredentialsRepository;

/**Classe CredentialsService
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class CredentialsService {

	@Autowired
	protected PasswordEncoder passwordEncoder;

	@Autowired
	protected CredentialsRepository credentialsRepository;

	@Transactional
	public Credentials getCredentials(Long id) {
		Optional<Credentials> result = this.credentialsRepository.findById(id);
		return result.orElse(null);
	}
	
	@Transactional
	public Credentials getCredentials(String username) {
		Optional<Credentials> result = this.credentialsRepository.findByUsername(username);
		return result.orElse(null);
	}

	@Transactional
	public Credentials saveCredentials(Credentials credentials) {
		credentials.setRuolo(Credentials.DEFAULT_ROLE);
		credentials.setPassword(this.passwordEncoder.encode(credentials.getPassword()));
		return this.credentialsRepository.save(credentials);
	}
	
	@Transactional
	public Credentials saveCredentialsDocente(Credentials credentials) {
		credentials.setRuolo(Credentials.ADMIN_ROLE);
		credentials.setPassword(this.passwordEncoder.encode(credentials.getPassword()));
		return this.credentialsRepository.save(credentials);
	}
	
	
	@Transactional
	public Long ritornaCredenziali(Long id) {
		List<Credentials> list = new ArrayList<Credentials>();
		list = this.credentialsRepository.ritornaCredenziali(id);
		for(Credentials c : list)
			if(c!=null && c.getId()>0)
				return Long.valueOf(c.getId());
		 
		return Long.valueOf(null);
	}
	
	@Transactional
	public void aggiornaRuoloUtente(Long id, String ruolo) {
		this.credentialsRepository.updateRuolo(id, ruolo);		
	}
	

}
