package it.uniroma3.siw.universita.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import it.uniroma3.siw.universita.service.CorsoDiLaureaService;

/**Classe 
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * 
 */

@Controller
public class CorsoDiLaureaController {
	@Autowired
	private CorsoDiLaureaService corsoDiLaureaService;
	
	@RequestMapping(value = "/corsi", method = RequestMethod.GET)
    public String getCorsiDiLaurea(Model model) {
		/*l'attributo di model restituirà la tranzazione sql di museo al Service */
    	model.addAttribute("corsolaurea", this.corsoDiLaureaService.corsoDiLaureaCorsiPaginaIniziale());
    	model.addAttribute("corsi", this.corsoDiLaureaService.corsoDiLaureaCorso());
    	return "corsi.html";
    }
}
