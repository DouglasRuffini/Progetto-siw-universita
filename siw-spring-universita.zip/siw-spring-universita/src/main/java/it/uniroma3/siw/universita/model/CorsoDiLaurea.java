package it.uniroma3.siw.universita.model;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**Classe CorsoDiLaurea
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see CorsoDiLaurea
 */

@Entity
public class CorsoDiLaurea {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(nullable = true)
	private String codicelaurea;
	private String titolo;
	
	@OneToMany(mappedBy = "corsidilaurea", cascade = {CascadeType.ALL})
	private List<Corso> corsidilaurea2corsi;
	
	@OneToMany(mappedBy = "studenti", cascade = {CascadeType.ALL})
	private List<Studente> corsidilaurea2studente;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private Facolta facolta2corsodilaurea;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getCodicelaurea() {
		return codicelaurea;
	}

	public void setCodicelaurea(String codicelaurea) {
		this.codicelaurea = codicelaurea;
	}

	public List<Corso> getCorsidilaurea2corsi() {
		return corsidilaurea2corsi;
	}

	public void setCorsidilaurea2corsi(List<Corso> corsidilaurea2corsi) {
		this.corsidilaurea2corsi = corsidilaurea2corsi;
	}

	public List<Studente> getCorsidilaurea2studente() {
		return corsidilaurea2studente;
	}

	public void setCorsidilaurea2studente(List<Studente> corsidilaurea2studente) {
		this.corsidilaurea2studente = corsidilaurea2studente;
	}

	public Facolta getFacolta2corsodilaurea() {
		return facolta2corsodilaurea;
	}

	public void setFacolta2corsodilaurea(Facolta facolta2corsodilaurea) {
		this.facolta2corsodilaurea = facolta2corsodilaurea;
	}

	
	
}
