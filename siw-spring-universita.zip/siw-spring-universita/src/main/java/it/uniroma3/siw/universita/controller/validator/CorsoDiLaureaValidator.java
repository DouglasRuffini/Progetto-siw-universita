package it.uniroma3.siw.universita.controller.validator;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class CorsoDiLaureaValidator  implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {		
		return CorsoDiLaureaValidator.class.equals(clazz);
	}

	@Override
	public void validate(Object o, Errors errors) {
		
	}

}
