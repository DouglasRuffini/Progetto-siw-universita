package it.uniroma3.siw.universita.repository;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.universita.model.Docente;

public interface DocenteRepository extends CrudRepository<Docente, Long> {

	List<Docente> findByNomeAndCognome(String nome, String cognome);

	List<Docente> findByNomeOrCognome(String nome, String cognome);
	
	/*Attenzione!! i campi nel caso no Transactional sono quelli dichiarati nella
	 * classe altrimenti vanno indicati come trascritti nel database*/
	@Modifying(clearAutomatically = true)
    @Query("update Docente a set a.nome = :nome, "
    		+ " a.cognome = :cognome, "
    		+ " a.telefono = :telefono, a.email = :email  where a.id = :id") 
    public void update(@Param("id") Long id, @Param("nome") String nome, @Param("cognome") String cognome, 
    		    		@Param("telefono") String telefono, @Param("email") String email);
	
		
	@Modifying(clearAutomatically = true)
	@Query(value="select cognome, telefono, email, facolta2docenti_id  from Docente join Corso on Docente.id = Corso.docenti_id  where docenti_id = :id", nativeQuery = true)
	@Transactional
	public List<Docente> docentePerCorso(@Param("id") Long id);
	
	@Modifying(clearAutomatically = true)
	@Query(value="select cognome, telefono, email, facolta2docenti_id  from Docente  where id = :id", nativeQuery = true)
	@Transactional
	public List<Docente> docentePerIndex(@Param("id") Long id);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Corso set docenti_id = null where docenti_id = :id") 
	@Transactional
	public void dissociaCorso(@Param("id") Long id); 
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Docente set facolta2docenti_id = null where id = :id") 
	@Transactional
	public void dissociaUniversita(@Param("id") Long id); 
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Docente set facolta2docenti_id = :idFacolta where id = :id") 
	@Transactional
	public void associaUniversita(@Param("id") Long id, @Param("idFacolta") Long idFacolta);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Docente set credentials2docenti_id = null where id = :id") 
	@Transactional
	public void dissociaCredentials(@Param("id") Long id); 
	
	@Modifying(clearAutomatically = true)
	@Query(value="select Docente.id, nome, cognome from Docente join Credentials on Docente.credentials2docenti_id = Credentials.id where Credentials.ruolo in ('ADMIN', 'DEFAULT','') ", nativeQuery = true)
	@Transactional
	public List<Docente> ritornaCredenzialiDocenti();
	
	@Modifying(clearAutomatically = true)
    @Query(value="update Docente set  credentials2docenti_id = :credentials2docenti_id where id = :id", nativeQuery=true)
	@Transactional
	public void updateCredenzialiDocente(@Param("id") Long id, @Param("credentials2docenti_id") Long credentials2docenti_id);
	
	@Modifying(clearAutomatically = true)
	@Query(value="select id, nome, cognome, telefono, email, facolta2docenti_id, credentials2docenti_id  from Docente  where credentials2docenti_id = :id", nativeQuery = true)
	@Transactional
	public List<Docente> docentePerCredenziali(@Param("id") Long id);
	
}
