package it.uniroma3.siw.universita.controller.validator;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import it.uniroma3.siw.universita.model.Voto;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class VotoValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return Voto.class.equals(clazz);
		
	}

	@Override
	public void validate(Object o, Errors errors) {
		
	}

}
