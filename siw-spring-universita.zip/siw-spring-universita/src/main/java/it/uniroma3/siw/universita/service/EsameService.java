package it.uniroma3.siw.universita.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.universita.model.Corso;
import it.uniroma3.siw.universita.model.CorsoDiLaurea;
import it.uniroma3.siw.universita.model.Esame;
import it.uniroma3.siw.universita.repository.CorsoDiLaureaRepository;
import it.uniroma3.siw.universita.repository.CorsoRepository;
import it.uniroma3.siw.universita.repository.EsameRepository;

/**Classe FacoltaService
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class EsameService {
	@Autowired
	private EsameRepository esamiRepository;
	
	@Autowired
	private CorsoDiLaureaRepository corsoDiLaureaRepository;
	
	@Autowired
	private CorsoRepository corsiRepository;
	
	@Transactional
	public Esame inserisci(Esame esami) {
		return (Esame) esamiRepository.save(esami);
	}	
	
	@Transactional
	public void eliminaEsame(Esame esami) {
		esamiRepository.delete(esami);
	}
	
	@Transactional
	public void eliminaEsameId(Long id) {
		esamiRepository.deleteById(id);
	}	
		
	@Transactional
	public List<Esame> esamiPerCodiceCorso(String codice) {
		return (List<Esame>) esamiRepository.findByCodiceCorso(codice);
	}
	
	public List<Esame> findByIDCorso(Long id){
		return (List<Esame>) esamiRepository.findByIDCorso(id);
	}
	
	public List<Esame> findByIDCorsoSuperato(Long id){
		return (List<Esame>) esamiRepository.findByIDCorsoSuperato(id);
	}
	
	@Transactional
	public List<Esame> findByEsameCalendario() {
		return (List<Esame>) esamiRepository.findByEsameCalendario();
	}
	
	@Transactional
	public Esame esamiPerId(Long id) {
		Optional<Esame> esami =esamiRepository.findById(id);

		if (esami.isPresent())
			return esami.get();
		else 
			return null;
	}
	
	@Transactional
	public List<Esame> esamiPerIndex(Long id) {
		return (List<Esame>) esamiRepository.findByEsamiPerIndexEsame(id);
	}
	
	@Transactional
	public boolean alreadyExists(Long id) {
		return this.esamiRepository.existsById(id);
	}
	
	@Transactional
	public boolean alreadyNotExists() {
		if(this.tuttiGliEsami().isEmpty())
			return true;
		return false;
	}
	
	
	/*query pagina calendario esami*/
	@Transactional
	public List<Corso> calendariEsami() {		
		return  (List<Corso>) corsiRepository.calendarioEsami();
	}
		
	@Transactional
	public List<CorsoDiLaurea> findByCorsoCalendario() {		
		return  (List<CorsoDiLaurea>) corsoDiLaureaRepository.findByCorsoCalendario();
	}
	
	@Transactional
	public List<Esame> tuttiGliEsami() {
		return (List<Esame>) esamiRepository.findAll();
	}

	
	/*Prenotazione esame*/
	
	@Transactional
	public List<Esame> findByEsamiSuperati(String codicecorso, Long idStudente){
		return (List<Esame>) esamiRepository.findByEsamiSuperati(codicecorso, idStudente);
	}
	
		
	@Transactional
	public List<Esame>  findByEsamiNonSuperati(String codicecorso, Long idStudente) {
		return (List<Esame>) esamiRepository.findByEsamiNonSuperati(codicecorso, idStudente);
	}
	
			
	@Transactional
	public List<Esame> findByEsamiPerIdEsame(Long idesame, Long idStudente, String data) {
		return (List<Esame>) esamiRepository.findByEsamiPerIdEsame(idesame, idStudente, data);
	}
	
		
	@Transactional
	public List<Esame>  findByEsamiPerCodiceEsame(String codicecorso, Long idStudente) {
		return (List<Esame>) esamiRepository.findByEsamiPerCodiceEsame(codicecorso, idStudente);
	}
	
		
	@Transactional
	public List<Esame>  findByEsamiPrenotatiNonEffettuati(String codicecorso, Long idStudente) {
		return (List<Esame>) esamiRepository.findByEsamiPrenotatiNonEffettuati(codicecorso, idStudente);
	}
	
	/*lista esami*/
	
	@Transactional
	public List<Esame> listaEsamiSuperati(Long idStudente){
		return (List<Esame>) esamiRepository.listaEsamiSuperati(idStudente);
	}
	
	@Transactional
	public List<Esame> listaEsamiNonSuperati(Long idStudente){
		return (List<Esame>) esamiRepository.listaEsamiNonSuperati(idStudente);
	}
	
	@Transactional
	public List<Esame> listaEsamiPrenotati(Long idStudente){
		return (List<Esame>) esamiRepository.listaEsamiPrenotati(idStudente);
	}
	
	@Transactional
	public List<Esame> listaEsamiPrenotatiPerDocenti(String codicecorso ,String data, Long iDdocenti  ){
		return (List<Esame>) this.esamiRepository.listaEsamiPrenotatiPerDocenti(codicecorso , data, iDdocenti);
	}
	
	
	
	
	
	
	
	
}
