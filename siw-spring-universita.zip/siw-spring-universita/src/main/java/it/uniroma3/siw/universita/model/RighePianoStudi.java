package it.uniroma3.siw.universita.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**Classe Corso
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see Corso
 */

@Entity
public class RighePianoStudi {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private PianoDiStudio piani2righe;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private Studente piani2studenti;
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private Corso pianocorsi2righe;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public PianoDiStudio getPiani2righe() {
		return piani2righe;
	}

	public void setPiani2righe(PianoDiStudio piani2righe) {
		this.piani2righe = piani2righe;
	}

	public Studente getPiani2studenti() {
		return piani2studenti;
	}

	public void setPiani2studenti(Studente piani2studenti) {
		this.piani2studenti = piani2studenti;
	}

	public Corso getPianocorsi2righe() {
		return pianocorsi2righe;
	}

	public void setPianocorsi2righe(Corso pianocorsi2righe) {
		this.pianocorsi2righe = pianocorsi2righe;
	}
	
	
}
