package it.uniroma3.siw.universita.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.universita.model.Studente;
import it.uniroma3.siw.universita.repository.StudenteRepository;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class StudenteService {
	@Autowired
	private StudenteRepository studenteRepository; 

	/**
	 * This method retrieves a User from the DB based on its ID.
	 * @param id the id of the User to retrieve from the DB
	 * @return the retrieved User, or null if no User with the passed ID could be found in the DB
	 */
	@Transactional
	public Studente getUser(Long id) {
		Optional<Studente> result = this.studenteRepository.findById(id);
		return result.orElse(null);
	}

	/**
	 * This method saves a User in the DB.
	 * @param user the User to save into the DB
	 * @return the saved User
	 * @throws DataIntegrityViolationException if a User with the same username
	 *                              as the passed User already exists in the DB
	 */
	@Transactional
	public Studente saveUser(Studente studente) {
		return this.studenteRepository.save(studente);
	}

	/**
	 * This method retrieves all Users from the DB.
	 * @return a List with all the retrieved Users
	 */
	@Transactional
	public List<Studente> getAllUsers() {
		List<Studente> result = new ArrayList<>();
		Iterable<Studente> iterable = this.studenteRepository.findAll();
		for(Studente studente : iterable)
			result.add(studente);
		return result;
	}
	
	@Transactional
	public List<Studente> tuttiGliUtenti(){
		return (List<Studente>) this.studenteRepository.findAll();
	}
	
	@Transactional
	public List<Studente> ritornaUtenza(Long id){
		return (List<Studente>) this.studenteRepository.ritornaCredenzialiStudente(id);		
	}
	
	@Transactional
	public void updateCorsoDiLaureaStudente(Long id, Long idCorsoDiLaurea) {
		this.studenteRepository.updateCorsoDiLaureaStudente(id, idCorsoDiLaurea);
	}
	
	@Transactional
	public List<Studente> ritornaIndiceStudente(Long id){
		return (List<Studente>) this.studenteRepository.ritornaIndiceStudente(id);
	}
	
	@Transactional
	public boolean alreadyExistsCorsoDiLaureaStudenteNullo(Long id) {
		List<Studente> coll = this.studenteRepository.verificaIndiceCorsoDiLaureaStudenteNullo(id);
		if (coll.size() > 0)
			return true;
		else 
			return false;
	}
	
	@Transactional
	public List<Studente> listaEsamiPrenotatiPerDocenti(String codicecorso ,String data, Long iDdocenti  ){
		return (List<Studente>) this.studenteRepository.listaEsamiPrenotatiPerDocenti(codicecorso , data, iDdocenti);
	}
	
}
