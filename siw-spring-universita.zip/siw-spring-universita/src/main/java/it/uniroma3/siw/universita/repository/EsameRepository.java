package it.uniroma3.siw.universita.repository;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.universita.model.Esame;

/**Classe FacoltaService
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface EsameRepository extends CrudRepository<Esame, Long> {
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, "
    		+ " esame.data, esame.corsi2esami_id "
    		+ "	FROM (corso  join corso_di_laurea  on corso.corsidilaurea_id = corso_di_laurea.id) join esame  on corso.id = esame.corsi2esami_id "
    		+ " WHERE cast (esame.data as date) >= NOW() ORDER BY corso.id", nativeQuery=true) 
	@Transactional
	public List<Esame> findByEsameCalendario();
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, "
    		+ " esame.data, esame.corsi2esami_id "
    		+ "	FROM corso join esame on corso.id = esame.corsi2esami_id "
    		+ " WHERE corso.codicecorso = :CodiceCorso and  cast (esame.data as date) >= NOW() ", nativeQuery=true) 
	@Transactional
	public List<Esame> findByCodiceCorso(@Param("CodiceCorso") String CodiceCorso);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, "
    		+ " esame.data, esame.corsi2esami_id "
    		+ "	FROM corso join esame on corso.id = esame.corsi2esami_id "
    		+ " WHERE esame.corsi2esami_id = :idCorso and  cast (esame.data as date) >= NOW() ", nativeQuery=true) 
	@Transactional
	public List<Esame> findByIDCorso(@Param("idCorso") Long idCorso);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, "
    		+ " esame.data, esame.corsi2esami_id "
    		+ "	FROM (corso  join corso_di_laurea  on corso.corsidilaurea_id = corso_di_laurea.id) join esame  on corso.id = esame.corsi2esami_id "
    		+ " WHERE corso_di_laurea.id = :idCorso and  cast (esame.data as date) >= NOW() ", nativeQuery=true) 	
	@Transactional
	public List<Esame> findByIDCorsoSuperato(@Param("idCorso") Long idCorso);

	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, esame.data, esame.corsi2esami_id " 
    		+ " FROM ((corso join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE corso.codicecorso = :Codicecorso and studente.id = :idStudente and voto.voto >= 18  ",  nativeQuery=true)
	@Transactional
	public List<Esame> findByEsamiSuperati(@Param("Codicecorso") String codicecorso, @Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, esame.data, esame.corsi2esami_id " 
    		+ " FROM ((corso join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE corso.codicecorso = :Codicecorso and studente.id  = :idStudente and voto.voto between 1 and 17  ",  nativeQuery=true)
	@Transactional
	public List<Esame> findByEsamiNonSuperati(@Param("Codicecorso") String codicecorso, @Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, esame.data, esame.corsi2esami_id " 
    		+ " FROM ((corso join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE esame.id = :idesame and studente.id  = :idStudente and esame.data =:data  ",  nativeQuery=true)
	@Transactional
	public List<Esame> findByEsamiPerIdEsame(@Param("idesame") Long idesame, @Param("idStudente") Long idStudente, @Param("data") String data);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, esame.data, esame.corsi2esami_id " 
    		+ " FROM ((corso join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE corso.codicecorso = :Codicecorso  and studente.id  = :idStudente  ",  nativeQuery=true)
	@Transactional
	public List<Esame> findByEsamiPerCodiceEsame(@Param("Codicecorso") String codicecorso,  @Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, esame.data, esame.corsi2esami_id " 
    		+ " FROM esame  "
    		+ " WHERE esame.id = :idesame  ",  nativeQuery=true)
	@Transactional
	public List<Esame> findByEsamiPerIndexEsame(@Param("idesame") Long id);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, esame.data, esame.corsi2esami_id " 
    		+ " FROM ((corso join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE corso.codicecorso = :Codicecorso and studente.id  = :idStudente and voto.voto = 0  ",  nativeQuery=true)
	@Transactional
	public List<Esame> findByEsamiPrenotatiNonEffettuati(@Param("Codicecorso") String codicecorso, @Param("idStudente") Long idStudente);
	
	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, esame.data, esame.corsi2esami_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE studente.id = :idStudente and voto.voto >= 18  ORDER BY corso.codicecorso  ",  nativeQuery=true)
	@Transactional
	public List<Esame> listaEsamiSuperati(@Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, esame.data, esame.corsi2esami_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE  studente.id  = :idStudente and voto.voto between 1 and 17  ORDER BY corso.codicecorso  ",  nativeQuery=true)
	@Transactional
	public List<Esame> listaEsamiNonSuperati(@Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, esame.data, esame.corsi2esami_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE studente.id = :idStudente and voto.voto = 0  ORDER BY corso.codicecorso  ",  nativeQuery=true)
	@Transactional
	public List<Esame> listaEsamiPrenotati(@Param("idStudente") Long idStudente);
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT esame.id, esame.data, esame.corsi2esami_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ "  WHERE corso.codicecorso = :codicecorso and esame.data = :data and corso.docenti_id = :iDdocenti  ORDER BY corso.codicecorso  ",  nativeQuery=true)
	@Transactional
	public List<Esame> listaEsamiPrenotatiPerDocenti(@Param("codicecorso") String codicecorso , @Param("data") String data, @Param("iDdocenti") Long iDdocenti  );
}






























