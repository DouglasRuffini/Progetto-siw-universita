package it.uniroma3.siw.universita.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.universita.model.PianoDiStudio;
import it.uniroma3.siw.universita.repository.PianoDiStudioRepository;


/**Classe FacoltaService
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class PianoDiStudioService {
	@Autowired
	private PianoDiStudioRepository pianoDiStudioRepository;
	
	@Transactional
	public PianoDiStudio inserisci(PianoDiStudio pianoDiStudio) {
		return (PianoDiStudio) pianoDiStudioRepository.save(pianoDiStudio);
	}
	
	@Transactional
	public void eliminaPianoDiStudio(PianoDiStudio pianoDiStudio) {
		pianoDiStudioRepository.delete(pianoDiStudio);
	}
	
	@Transactional
	public void eliminaPianoDiStudioId(Long id) {
		pianoDiStudioRepository.deleteById(id);
	}
	
	@Transactional
	public List<PianoDiStudio> tuttiPianoDiStudio() {
		return (List<PianoDiStudio>) pianoDiStudioRepository.findAll();
	}

	@Transactional
	public PianoDiStudio corsoPerId(Long id) {
		Optional<PianoDiStudio> pianoDiStudio =pianoDiStudioRepository.findById(id);

		if (pianoDiStudio.isPresent())
			return pianoDiStudio.get();
		else 
			return null;
	}
	
	@Transactional
	public boolean alreadyExists(Long id) {
		return this.pianoDiStudioRepository.existsById(id);
	}
	
	@Transactional
	public boolean alreadyNotExists() {
		if(this.tuttiPianoDiStudio().isEmpty())
			return true;
		return false;
	}
	
}
