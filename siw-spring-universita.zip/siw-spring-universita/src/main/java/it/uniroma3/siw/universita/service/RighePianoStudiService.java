package it.uniroma3.siw.universita.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.universita.model.RighePianoStudi;
import it.uniroma3.siw.universita.repository.RighePianoStudiRepository;

/**Classe FacoltaService
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class RighePianoStudiService {

	@Autowired
	private RighePianoStudiRepository righePianoStudiRepository;
	
	@Transactional
	public RighePianoStudi inserisci(RighePianoStudi righePianoStudi) {
		return (RighePianoStudi) righePianoStudiRepository.save(righePianoStudi);
	}
	
	@Transactional
	public void eliminaRighePianoStudi(RighePianoStudi righePianoStudi) {
		righePianoStudiRepository.delete(righePianoStudi);
	}
	
	@Transactional
	public void eliminaRighePianoStudiId(Long id) {
		righePianoStudiRepository.deleteById(id);
	}
	
	@Transactional
	public List<RighePianoStudi> tutteLeRighePianoStudi() {
		return (List<RighePianoStudi>) righePianoStudiRepository.findAll();
	}

	@Transactional
	public RighePianoStudi corsoPerId(Long id) {
		Optional<RighePianoStudi> righePianoStudi =righePianoStudiRepository.findById(id);

		if (righePianoStudi.isPresent())
			return righePianoStudi.get();
		else 
			return null;
	}
	
	@Transactional
	public boolean alreadyExists(Long id) {
		return this.righePianoStudiRepository.existsById(id);
	}
	
	@Transactional
	public boolean alreadyNotExists() {
		if(this.tutteLeRighePianoStudi().isEmpty())
			return true;
		return false;
	}
	

}
