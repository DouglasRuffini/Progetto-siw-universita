package it.uniroma3.siw.universita.repository;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.universita.model.Facolta;

/**Classe FacoltaRepository
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface FacoltaRepository extends CrudRepository<Facolta, Long> {
	
	public List<Facolta> findByNome(String nome);
	
	@Modifying(clearAutomatically = true)
    @Query("update Facolta a set a.nome = :nome, "
    		+ "a.indirizzo = :indirizzo, a.telefono = :telefono, a.email = :email  where a.id = :id") 
    public void update(@Param("id") Long id, @Param("nome") String nome, @Param("indirizzo") String indirizzo, 
    		@Param("telefono") String telefono, @Param("email") String email);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Docente set facolta2docenti_id = null where facolta2docenti_id = :id") 
	@Transactional
	public void dissociaDocenti(@Param("id") Long id);
	
	
	
}
