package it.uniroma3.siw.universita.repository;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.universita.model.Voto;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface VotoRepository  extends CrudRepository<Voto, Long>{
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT voto.id, voto, esame2voto_id, studenti2esami_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE studente.id = :idStudente and voto.voto >= 18  ORDER BY corso.codicecorso  ",  nativeQuery=true)
	@Transactional
	public List<Voto> listaEsamiSuperati(@Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT  voto.id, voto, esame2voto_id, studenti2esami_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE  studente.id  = :idStudente and voto.voto between 1 and 17  ORDER BY corso.codicecorso  ",  nativeQuery=true)
	@Transactional
	public List<Voto> listaEsamiNonSuperati(@Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT  voto.id, voto, esame2voto_id, studenti2esami_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE studente.id = :idStudente and voto.voto = 0  ORDER BY corso.codicecorso  ",  nativeQuery=true)
	@Transactional
	public List<Voto> listaEsamiPrenotati(@Param("idStudente") Long idStudente);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT  voto.id, voto, esame2voto_id, studenti2esami_id " 
    		+ " FROM (((corso join corso_di_laurea on corso.corsidilaurea_id = corso_di_laurea.id) join esame on corso.id = esame.corsi2esami_id) join voto on esame.id=voto.esame2voto_id) join studente on studente.id = voto.studenti2esami_id "
    		+ " WHERE corso.codicecorso = :codicecorso and esame.data = :data and corso.docenti_id = :iDdocenti  ORDER BY corso.codicecorso  ",  nativeQuery=true)
	@Transactional
	public List<Voto> listaEsamiPrenotatiPerDocenti(@Param("codicecorso") String codicecorso , @Param("data") String data, @Param("iDdocenti") Long iDdocenti  );


	@Modifying(clearAutomatically = true)
    @Query(value = "SELECT  voto.id, voto, esame2voto_id, studenti2esami_id " 
    		+ " FROM voto  "
    		+ " WHERE id = :id   ",  nativeQuery=true)
	@Transactional
	public List<Voto> aggiornaVotodocente(@Param("id") Long id );











}
