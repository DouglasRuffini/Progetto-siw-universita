package it.uniroma3.siw.universita.controller;
import org.springframework.stereotype.Controller;

/**Classe 
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * 
 */

@Controller
public class CorsoController {

}
