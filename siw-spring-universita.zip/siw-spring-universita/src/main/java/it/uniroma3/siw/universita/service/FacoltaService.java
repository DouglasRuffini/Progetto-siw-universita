package it.uniroma3.siw.universita.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.universita.model.Facolta;
import it.uniroma3.siw.universita.repository.FacoltaRepository;

/**Classe FacoltaService
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class FacoltaService {
	
	@Autowired
	private FacoltaRepository facoltaRepository;
	
	@Transactional
	public Facolta inserisci(Facolta facolta) {
		return (Facolta) facoltaRepository.save(facolta);
	}
	
	@Transactional
	public void aggiorna(Facolta facolta) {
		facoltaRepository.update(facolta.getId(), facolta.getNome(), facolta.getIndirizzo(), facolta.getTelefono(), facolta.getEmail());
	}
	
	@Transactional
	public void eliminaFacolta(Facolta facolta) {
		facoltaRepository.delete(facolta);
	}
	
	@Transactional
	public void eliminaFacoltaId(Long id) {
		facoltaRepository.deleteById(id);
	}
	
	
	@Transactional
	public void dissociaDocenti(Long id) {
		facoltaRepository.dissociaDocenti(id);
	}
	
	@Transactional
	public List<Facolta> facoltaPerNome(String nome) {
		return facoltaRepository.findByNome(nome);
	}

	@Transactional
	public List<Facolta> tutteLeFacolta() {
		return (List<Facolta>) facoltaRepository.findAll();
	}

	@Transactional
	public Facolta facoltaPerId(Long id) {
		Optional<Facolta> facolta =facoltaRepository.findById(id);

		if (facolta.isPresent())
			return facolta.get();
		else 
			return null;
	}

	@Transactional
	public boolean alreadyExistsFacoltaNome(Facolta facolta) {
		List<Facolta> coll = this.facoltaRepository.findByNome(facolta.getNome());
		if (coll.size() > 0)
			return true;
		else 
			return false;
	}
	
	@Transactional
	public boolean alreadyExists(Long id) {
		return this.facoltaRepository.existsById(id);
	}
	
	@Transactional
	public boolean alreadyNotExists() {
		if(this.tutteLeFacolta().isEmpty())
			return true;
		return false;
	}

}
