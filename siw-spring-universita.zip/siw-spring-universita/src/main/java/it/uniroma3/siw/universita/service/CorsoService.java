package it.uniroma3.siw.universita.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.universita.model.Corso;
import it.uniroma3.siw.universita.repository.CorsoRepository;

/**Classe FacoltaService
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class CorsoService {

	@Autowired
	private CorsoRepository corsoRepository;
	
	@Transactional
	public Corso inserisci(Corso corso) {
		return (Corso) corsoRepository.save(corso);
	}
	
	@Transactional
	public void eliminaCorso(Corso corso) {
		corsoRepository.delete(corso);
	}
	
	@Transactional
	public void eliminaCorsoId(Long id) {
		corsoRepository.deleteById(id);
	}
	
	@Transactional
	public List<Corso> corsoPerNome(String nome) {
		return corsoRepository.findByNome(nome);
	}
	
	public List<Corso> corsoPerIndiceDiLaureaCorsi(Long idCorsoDiLaurea){
		return corsoRepository.corsoPerIndiceDiLaureaCorsi(idCorsoDiLaurea);
	}
	
	public List<Corso> corsoPerIndiceCorsi(Long id){
		return corsoRepository.corsoPerIndiceCorsi(id);
	}

	@Transactional
	public List<Corso> tuttiICorsi() {
		return (List<Corso>) corsoRepository.findAll();
	}

	@Transactional
	public Corso corsoPerId(Long id) {
		Optional<Corso> corso =corsoRepository.findById(id);

		if (corso.isPresent())
			return corso.get();
		else 
			return null;
	}

	@Transactional
	public boolean alreadyExistsCorsoNome(Corso corso) {
		List<Corso> coll = this.corsoRepository.findByNome(corso.getNome());
		if (coll.size() > 0)
			return true;
		else 
			return false;
	}
	
	@Transactional
	public boolean alreadyExists(Long id) {
		return this.corsoRepository.existsById(id);
	}
	
	@Transactional
	public boolean alreadyNotExists() {
		if(this.tuttiICorsi().isEmpty())
			return true;
		return false;
	}
	
	@Transactional
	public List<Corso> corsoDocente(Long id) {
		return corsoRepository.corsiDocente(id);
	}


	/*lista esami*/
	@Transactional	
	public List<Corso> listaEsamiSuperati(Long idStudente){
		return (List<Corso>) corsoRepository.listaEsamiSuperati(idStudente);
	}
	
	@Transactional
	public List<Corso> listaEsamiNonSuperati(Long idStudente){
		return (List<Corso>) corsoRepository.listaEsamiNonSuperati(idStudente);
	}
	
	@Transactional
	public List<Corso> listaEsamiPrenotati(Long idStudente){
		return (List<Corso>) corsoRepository.listaEsamiPrenotati(idStudente);
	}
	
	@Transactional
	public List<Corso> listaEsamiPrenotatiPerDocenti(String codicecorso ,String data, Long iDdocenti  ){
		return (List<Corso>) corsoRepository.listaEsamiPrenotatiPerDocenti(codicecorso , data, iDdocenti);
	}
	
	@Transactional
	public List<Corso> listaCorsiPerDocenti(Long iDdocenti  ){
		return (List<Corso>) corsoRepository.listaCorsiPerDocenti(iDdocenti);
	}
}













